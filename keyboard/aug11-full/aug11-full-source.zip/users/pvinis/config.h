#pragma once

// #define TAPPING_TERM 150

#if defined(MOUSE_KEYS)
#    define MOUSEKEY_WHEEL_TIME_TO_MAX 1
#endif
