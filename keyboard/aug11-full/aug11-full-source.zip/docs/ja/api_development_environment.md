# 開発環境のセットアップ

<!---
  original document: 0.9.50:docs/api_development_environment.md
  git diff 0.9.50 HEAD -- docs/api_development_environment.md | cat
-->

開発環境をセットアップするには、[qmk_web_stack](https://github.com/qmk/qmk_web_stack) に行ってください。
